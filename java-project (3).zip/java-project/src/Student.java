
class Student {

    // Attributes
    int rollNo;
    String name;
    String branch;
    int age;

    // Method to display student information
    void displayInfo() {
        System.out.println("Student Information");
        System.out.println("Roll Number: " + rollNo);
        System.out.println("Name: " + name);
        System.out.println("Branch: " + branch);
        System.out.println("Age: " + age);
    }

    // Main method
    public static void main(String[] args) {

        // Creating an object
        Student s1 = new Student();

        // Assigning values
        s1.rollNo = 101;
        s1.name = "Harshi";
        s1.branch = "CSE";
        s1.age = 19;

        // Calling the method
        s1.displayInfo();
    }
}
