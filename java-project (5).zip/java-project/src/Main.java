
import java.util.ArrayList;
import java.util.Scanner;

// Book class
class Book {
    private int bookId;
    private String title;
    private String author;
    private boolean available;

    // Constructor
    Book(int bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.available = true;
    }

    // Getter methods
    public int getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public boolean isAvailable() {
        return available;
    }

    // Setter method
    public void setAvailable(boolean available) {
        this.available = available;
    }

    void displayBook() {
        System.out.println("Book ID: " + bookId);
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Available: " + available);
        System.out.println("--------------------");
    }
}

// Library class
class Library {
    ArrayList<Book> books = new ArrayList<>();

    // Add Book
    void addBook(Book book) {
        books.add(book);
        System.out.println("Book added successfully!");
    }

    // Borrow Book
    void borrowBook(int id) {
        for (Book book : books) {
            if (book.getBookId() == id) {
                if (book.isAvailable()) {
                    book.setAvailable(false);
                    System.out.println("Book borrowed successfully!");
                } else {
                    System.out.println("Book is already borrowed!");
                }
                return;
            }
        }
        System.out.println("Book not found!");
    }

    // Return Book
    void returnBook(int id) {
        for (Book book : books) {
            if (book.getBookId() == id) {
                if (!book.isAvailable()) {
                    book.setAvailable(true);
                    System.out.println("Book returned successfully!");
                } else {
                    System.out.println("Book was not borrowed!");
                }
                return;
            }
        }
        System.out.println("Book not found!");
    }

    // Display all books
    void displayBooks() {
        if (books.isEmpty()) {
            System.out.println("No books available!");
            return;
        }

        for (Book book : books) {
            book.displayBook();
        }
    }
}

// Abstract User class
abstract class User {
    protected String name;
    protected int userId;

    User(String name, int userId) {
        this.name = name;
        this.userId = userId;
    }

    // Abstract method
    abstract void displayUserDetails();
}

// Student inherits User
class Student extends User {

    Student(String name, int userId) {
        super(name, userId);
    }

    @Override
    void displayUserDetails() {
        System.out.println("Student Name: " + name);
        System.out.println("User ID: " + userId);
    }
}

// Main class
public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Library library = new Library();

        Student student = new Student("Harshi", 101);

        int choice;

        do {
            System.out.println("\n===== LIBRARY MANAGEMENT SYSTEM =====");
            System.out.println("1. Add Book");
            System.out.println("2. Display Books");
            System.out.println("3. Borrow Book");
            System.out.println("4. Return Book");
            System.out.println("5. Display User Details");
            System.out.println("6. Exit");

            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:
                    System.out.print("Enter Book ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter Book Title: ");
                    String title = sc.nextLine();

                    System.out.print("Enter Author Name: ");
                    String author = sc.nextLine();

                    Book book = new Book(id, title, author);
                    library.addBook(book);
                    break;

                case 2:
                    library.displayBooks();
                    break;

                case 3:
                    System.out.print("Enter Book ID to borrow: ");
                    int borrowId = sc.nextInt();
                    library.borrowBook(borrowId);
                    break;

                case 4:
                    System.out.print("Enter Book ID to return: ");
                    int returnId = sc.nextInt();
                    library.returnBook(returnId);
                    break;

                case 5:
                    student.displayUserDetails();
                    break;

                case 6:
                    System.out.println("Thank you for using Library Management System!");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }

        } while (choice != 6);

        sc.close();
    }
}
