
// Base class
class Vehicle {

    void start() {
        System.out.println("Vehicle is starting");
    }

    void display() {
        System.out.println("This is a vehicle");
    }
}

// Subclass Car
class Car extends Vehicle {

    @Override
    void start() {
        System.out.println("Car starts with a key");
    }

    @Override
    void display() {
        System.out.println("This is a Car");
    }
}

// Subclass Bike
class Bike extends Vehicle {

    @Override
    void start() {
        System.out.println("Bike starts with a self-start button");
    }

    @Override
    void display() {
        System.out.println("This is a Bike");
    }
}

// Main class
public class Main {

    public static void main(String[] args) {

        // Creating objects
        Car c1 = new Car();
        Bike b1 = new Bike();

        // Calling Car methods
        System.out.println("Car Details:");
        c1.start();
        c1.display();

        // Calling Bike methods
        System.out.println("\nBike Details:");
        b1.start();
        b1.display();
    }
}
